public string InputStyle(ColumnSchema column)  
{
string strColType = column.NativeType;
    switch (strColType)
		{
			case "tinynt":			return "TxtInC";
			case "smallint":		return "TxtInC";
			case "int":				return "TxtInC";
			case "bigint":			return "TxtInC";
			case "numeric":			return "TxtInC";

			case "char":			return "TextIn";

			case "nvarchar":		return "TextIn";
			case "varchar":			return "TextIn";

			case "date":			return "TxtInC";
			case "smalldatetime":	return "TxtInC";
			case "datetime":		return "TxtInC";

			case "decimal":			return "TxtInR";
			case "float":			return "TxtInR";
			case "money":			return "TxtInR";

			case "xml":				return "TextIn";
			case "bit":				return "TextIn";

			default:				return "TextIn";
        }		
	
}