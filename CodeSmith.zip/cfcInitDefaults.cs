﻿public string CFDefault(ColumnSchema column)
{
string strColType = column.NativeType;
	
	<%= column.ExtendedProperties["CS_IsIdentity"].Value.ToString().ToLower() %>
<% if (column.ExtendedProperties.Contains("CS_IsIdentity") && column.ExtendedProperties["CS_IsIdentity"].Value.ToString().ToLower() == "true") { %>
	return 0;
<% } %>
string strDefault = (string)column.ExtendedProperties["CS_Default"].Value;
	switch (strColType)
		{
			case "bigint":
			case "bit":	
			case "decimal":	
			case "float":
			case "int":	
			case "money":
			case "numeric":
			case "smallint":
			case "tinyint":
				return strDefault;
				break;
			case "char":
			case "nvarchar":
			case "varchar":
			case "xml":	
				return strDefault;
				break;
			case "date":
			case "datetime":
			case "smalldatetime":
				return strDefault;
				break;

			default:
				return strDefault;
				break;
		}
}